import Server from "./server.js";

new Server() // Instanciar servidor